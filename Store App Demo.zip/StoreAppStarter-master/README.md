## Credit

This particular demo app is based on a project by Gary Shew, one of our former students. In week one we give an assignment to build a storefront for an application, and his example was so excellent that we are using it to teach! Thanks Gary!

You can see the demo we'll be building, which is Gary's finished Fromage Cheese shop here:

https://duder63.github.io/store_app/